import React from 'react';

import { Router, Redirect } from '@reach/router';

import Home from './views/Home';
import NewPet from './views/NewPet';
import EditPet from './views/EditPet';
import Pet from './views/Pet';

function App() {
  return (
    <div className="App">
      <Router>
        <Home path="pets" />
        <NewPet path="pets/new" />
        <EditPet path="pets/:id/edit" />
        <Pet path="pets/:id"/>
        <Redirect 
          from="/"
          to="/pets"
          noThrow
        />
      </Router>
    </div>
  );
}

export default App;
