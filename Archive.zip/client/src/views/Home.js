import React, {useState, useEffect} from 'react';

import axios from 'axios';
import { Link } from '@reach/router';
import { navigate } from '@reach/router';

const Home = () => {

    const [pets, setPets] = useState([]);

    console.log(pets);

    useEffect(() => {
        axios.get('http://localhost:9000/api/pets')
        .then(response => setPets(response.data))
        .catch(console.log)
    }, []);


    return (

        <div>
            <h1>Pet Shelter</h1>
            <h2>These pets are looking for a home!</h2>
            <Link to={'/pets/new'}>Add a pet to the shelter</Link>
            <table>
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Type</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    {pets.map((pet)=>(
                        <tr key={pet._id}>
                            <td>{pet.name}</td>
                            <td>{pet.type}</td>
                            <td>
                                <button onClick={()=>navigate('/pets/' + pet._id)}>Details</button>
                                <button onClick={()=>navigate('/pets/' + pet._id + '/edit')}>Edit</button>
                            </td>


                        </tr>

                    ))}
                </tbody>
            </table>
        </div>

    );


}

export default Home;