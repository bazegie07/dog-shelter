import React, { useEffect, useState} from 'react';

import axios from 'axios';
import { navigate, Link } from '@reach/router';

const Pet = ({ id }) => {

    const [pet, setPet] = useState(null);

    useEffect(()=> {
        axios.get('http://localhost:9000/api/pets/' +id)
        .then(response => setPet(response.data))
    }, []);

    function handleDelete(id) {
        axios.delete('http://localhost:9000/api/pets/' + id)
        .then(()=>{navigate('/pets')

        })
        
    }



    if(pet === null) {
        return 'Loading...';
    }

    return (
        <div>
            <Link to ={'/pets'}>Home</Link>
            <h1>Pet Shelter</h1>
            <h3>Details about {pet.name}</h3>
            
                <p>Pet type: {pet.type}</p>
                <p>Description:{ pet.description } </p>
                <p>Skills:</p>
                <p>{pet.skillone}</p>
                <p>{pet.skilltwo}</p>
                <p>{pet.skillthree}</p>
                <button onClick={()=> handleDelete(pet._id)}>Adopt this pet!</button>
        </div>
    );


}

export default Pet;