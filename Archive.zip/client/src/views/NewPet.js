import React, { useState } from 'react';

import axios from 'axios';
import { Link } from '@reach/router';
import { navigate } from '@reach/router';

const NewPet = () => {

    const [newPet, setNewPet] = useState({
        name: '',
        type: '',
        description: '',
        skillone: '',
        skilltwo: '',
        skillthree: ''
    });

    const [errors, setErrors] = useState([]);

    function onChangehandler(event) {
        setNewPet({
            ...newPet,
            [event.target.name]: event.target.value
        });
    }

    function handleSubmit (event) {
        event.preventDefault();

        axios.post('http://localhost:9000/api/pets', newPet)
        .then(() => navigate('/pets'))
        .catch(err => {
            const errorResponse = err.response.data.errors;
            const errorArr = [];
            for(const key of Object.keys(errorResponse)){
                errorArr.push(errorResponse[key].message)
            }
            setErrors(errorArr);
            console.log(err.response.data.errors)
        });
    }

    return (

        <div>
            <h1>Pet Shelter</h1>
            <h3>Know of a pet needing a home?</h3>
            {errors.map((err, index) => (
                <p key={index}>{err}</p>
            ))}
            <form onSubmit={handleSubmit}>
                <div>
                    <label>Pet name:</label>
                    <input name="name" value={newPet.name} onChange={onChangehandler}/>
                </div>
                <div>
                    <label>Pet type:</label>
                    <input name="type" value={newPet.type} onChange={onChangehandler}/>
                </div>
                <div>
                    <label>description</label>
                    <input name="description" value={newPet.description} onChange={onChangehandler}/>
                </div>
                <label>Skills:</label>
                <label>Skill 1:</label>
                <input name="skillone" value={newPet.skillone} onChange={onChangehandler} />
                <label>Skill 2:</label>
                <input name="skilltwo" value={newPet.skilltwo} onChange={onChangehandler} />
                <label>Skill 3:</label>
                <input name="skillthree" value={newPet.skillthree} onChange={onChangehandler} />

                <button>Add pet</button>
                <button onClick={() => navigate("/pets")}>Cancel</button>

            </form>

        </div>


    );

}

export default NewPet;