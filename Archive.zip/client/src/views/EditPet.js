import React, {useEffect, useState} from 'react';

import axios from 'axios';
import { navigate } from '@reach/router';

const EditPet =({ id }) => {

    const [pet, setPet] =useState(null);
    const [errors, setErrors] = useState([]);

    useEffect (() => {
        axios.get('http://localhost:9000/api/pets/' + id)
        .then(response => setPet(response.data))
    },[]);

    function onChangehandler(event) {
        setPet({
            ...pet,
            [event.target.name]: event.target.value
        })
    }

    function handleSumbit (event) {
        event.preventDefault();

        axios.put('http://localhost:9000/api/pets/' + id, pet)
        .then(()=>navigate('/pets/' + pet._id))
        .catch(err => {
            const errorResponse = err.response.data.errors;
            const errorArr = [];
            for(const key of Object.keys(errorResponse)){
                errorArr.push(errorResponse[key].message)
            }
            setErrors(errorArr);
            console.log(err.response.data.errors)
        });

    }

    if(pet === null){
        return 'Loading...'
    }


    return (

        <div>
            
            <h1>Pet Shelter</h1>
            <h3>Edit this pet</h3>
            {errors.map((err, index) => (
                <p key={index}>{err}</p>
            ))}
            <form onSubmit={handleSumbit}>
                <div>
                    <label>Pet name:</label>
                    <input name="name" value={pet.name} onChange={onChangehandler}/>
                </div>
                <div>
                    <label>Pet type:</label>
                    <input name="type" value={pet.type} onChange={onChangehandler}/>
                </div>
                <div>
                    <label>description</label>
                    <input name="description" value={pet.description} onChange={onChangehandler}/>
                </div>
                <label>Skills:</label>
                <label>Skill 1:</label>
                <input name="skillone" value={pet.skillone} onChange={onChangehandler} />
                <label>Skill 2:</label>
                <input name="skilltwo" value={pet.skilltwo} onChange={onChangehandler} />
                <label>Skill 3:</label>
                <input name="skillthree" value={pet.skillthree} onChange={onChangehandler} />

                <button >Edit pet</button>
                <button>Cancel</button>

            </form>

        
        </div>
    );



}

export default EditPet;